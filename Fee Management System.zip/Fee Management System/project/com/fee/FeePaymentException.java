package com.fee;
public class FeePaymentException extends Exception
{
	public FeePaymentException()
	{
		super();
	}
	public FeePaymentException(String message)
	{
		super(message);
	}
}